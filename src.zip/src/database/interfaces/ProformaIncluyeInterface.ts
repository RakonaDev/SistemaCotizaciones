export interface ProformaIncluyeInterface {
  nombre: string;
  id?: number;
  id_proforma_detail: number;
  created_at: string;
  updated_at: string;
}